#ifndef CONTADOR_H
#define CONTADOR_H

#include <stdbool.h>
#include "trie.h"

// estrutura do contador, armazena as palavras na trie e suas contagens
typedef struct Contador {
    Trie *trie_palavras; // trie para armazenar palavras
    int *contagens;      // vetor que armazena a contagem para cada palavra
    int capacidade;      // capacidade atual do vetor de contagens
} Contador;

// cria e inicializa um contador
Contador *cont_cria(void);

// destroi o contador e libera memória
void cont_destroi(Contador *c);

// processa uma palavra: insere na trie se nova ou incrementa contagem
void cont_processa_palavra(Contador *c, char *palavra);

// imprime todas as palavras e suas contagens
void cont_imprime(Contador *c);

#endif