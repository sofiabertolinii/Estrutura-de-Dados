#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "contador.h" 

// função para ler um arquivo de texto e alimentar o Contador
void processar_texto(Contador *c, const char *arquivo) {
    FILE *f = fopen(arquivo, "r");
    if (!f) {
        perror("Erro ao abrir arquivo de texto");
        return;
    }

    char palavra_suja[256];

    printf("\nIniciando leitura e contagem de palavras do arquivo: %s\n", arquivo);
    while (fscanf(f, "%255s", palavra_suja) == 1) {
        cont_processa_palavra(c, palavra_suja);
    }

    printf("Contagem concluida.\n");
    fclose(f);
}

// função principal

int main(void) {
    
    printf("=== CONTADOR DE PALAVRAS COM ESTRUTURA TRIE ===\n");
    printf("----------------------------------------------------------\n");
    
    const char *nome_arquivo = "texto_cont.txt";

    // cria o contador
    Contador *meu_contador = cont_cria();
    if (!meu_contador) {
        fprintf(stderr, "Erro: Nao foi possível criar a estrutura Contador.\n");
        return 1;
    }

    // processa o arquivo de texto
    processar_texto(meu_contador, nome_arquivo);

    // imprime o resultado final (palavra e sua contagem)
    cont_imprime(meu_contador);

    cont_destroi(meu_contador);
    
    printf("\nEncerrando a aplicacao Contador de Palavras.\n");
    
    return 0;
}