//exemplo de uso do dicionário implementado com Trie

#include <stdio.h>
#include <stdlib.h>
#include "dict.h"

int main(){
    Dict *d = dict_cria();

    //insiro palavras aleatórias no dicionário
    dict_insere_palavra(d, "Resiliência", "capacidade de se recobrar facilmente ou se adaptar à má sorte ou às mudanças.");
    dict_insere_palavra(d, "Efêmero", "algo que é passageiro, temporário, transitório");
    dict_insere_palavra(d, "Empatia", "habilidade de se colocar no lugar do outro, compreendendo seus sentimentos e perspectivas.");
    dict_insere_palavra(d, "Inércia", "tendência de um corpo resistir a qualquer mudança em seu estado de movimento.");
    dict_insere_palavra(d, "Paradoxo", "ideia ou afirmação que parece contraditória, mas que pode conter uma verdade oculta.");
    
    //busco palavra que existe
    if(dict_busca_palavra(d, "Empatia")) printf("Palavra 'Empatia' encontrada no dicionário!\n");
    else printf("Palavra 'Empatia' não encontrada no dicionário!\n");

    printf("\n");

    //busco palavra que não existe
    if(dict_busca_palavra(d, "Saudade")) printf("Palavra 'Saudade' encontrada no dicionário!\n");
    else printf("Palavra 'Saudade' não encontrada no dicionário!\n");

    printf("\n");

    //imprimo todas as palavras
    dict_imprime(d);

    //excluo uma palavra
    dict_remove_palavra(d, "Empatia");

    printf("\n");
    //imprimo todas as palavras novamente
    dict_imprime(d);

    dict_destroi(d);
}
