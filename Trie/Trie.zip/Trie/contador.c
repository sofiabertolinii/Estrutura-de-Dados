#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "contador.h"
#include "trie.h"

#define BLOCO_CAPACIDADE 10 // incremento de capacidade do vetor de contagens

// FUNÇÕES AUXILIARES DE NORMALIZAÇÃO

// converte caractere para minuscula (utf-8)
static unsigned char minusculas_utf8(unsigned char c) {
    if(c >= 'A' && c <= 'Z') {
        return c + ('a' - 'A');
    }
    return c; 
}

// verifica se o caractere é uma letra (utf-8)
static bool eh_letra_utf8(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= 0xC0);
}

// normaliza a palavra: remove pontuação e converte para minúsculas
static void normalizar_palavra(char *palavra) {
    int i = 0; // indice de leitura
    int j = 0; // indice de escrita
    
    while (palavra[i]) {
        unsigned char c = palavra[i];
        
        if (eh_letra_utf8(c)) { 
            palavra[j] = minusculas_utf8(c);
            j++;
            
            // se for um byte inicial de UTF-8, move os bytes subsequentes
            if (c >= 0xC0) {
                i++;
                while ((palavra[i] & 0xC0) == 0x80) { 
                    palavra[j] = palavra[i];
                    i++;
                    j++;
                }
                i--; 
            }
            
        } else {
            // se for pontuação ou espaço, considera o fim da palavra
            break; 
        }
        i++;
    }
    
    // finaliza a nova string limpa
    palavra[j] = '\0';
}

// FUNÇÕES PRINCIPAIS DO CONTADOR

// cria um contador vazio
Contador *cont_cria(void) 
{
    Contador *c = malloc(sizeof(Contador));
    if (c == NULL) return NULL;

    c->trie_palavras = tr_cria();
    c->capacidade = BLOCO_CAPACIDADE;
    c->contagens = calloc(c->capacidade, sizeof(int));

    if (c->trie_palavras == NULL || c->contagens == NULL){
        if (c->trie_palavras) tr_destroi(c->trie_palavras);
        if (c->contagens) free(c->contagens);
        free(c);
        return NULL;
    }

    return c;
}

// destrói o contador
void cont_destroi(Contador *c)
{
    if (c == NULL) return;

    tr_destroi(c->trie_palavras);
    free(c->contagens);
    free(c);
}

// processa uma palavra: insere/atualiza contagem
void cont_processa_palavra(Contador *c, char *palavra)
{
    normalizar_palavra(palavra);
    if (strlen(palavra) == 0) return; // palavra vazia após

    // garante que a palavra está na trie
    tr_inserir(c->trie_palavras, palavra);

    // obtem o índice da palavra na trie
    int index = tr_indice_palavra(c->trie_palavras, palavra);
    if (index < 0) return; 

    // verifica e realoca o vetor de contagens se necessário
    if (index >= c->capacidade) {
        int antigaCap = c->capacidade;
        while (index >= c->capacidade) c->capacidade += BLOCO_CAPACIDADE;
        c->contagens = realloc(c->contagens, c->capacidade * sizeof(int));
        // inicializa novas posições para 0
        for (int i = antigaCap; i < c->capacidade; i++) {
            c->contagens[i] = 0;
        }
    }
    c->contagens[index]++;
}

//exibe todas as palavras e suas contagens
void cont_imprime(Contador *c) 
{
    if (c == NULL || c->trie_palavras->qtd_palavras == 0) {
        printf("Nenhuma palavra para contar.\n");
        return;
    }

    // obtem um vetor com todas as palavras armazenadas na trie
    char **listaDePalavras = tr_palavras(c->trie_palavras);
    int qtd = c->trie_palavras->qtd_palavras;

    printf("\n--- Palavras e Ocorrencias ---\n");
    for (int i = 0; i < qtd; i++){
        // reconsulta o indice para garantir a correspondência
        int index = tr_indice_palavra(c->trie_palavras, listaDePalavras[i]);
        if (index >= 0 && index < c->capacidade) {
            printf("%s: %d ocorrencia(s)\n", listaDePalavras[i], c->contagens[index]);
        }

        // libera memoria da string
        free(listaDePalavras[i]);
    }

    free(listaDePalavras); // libera o vetor de ponteiros
}